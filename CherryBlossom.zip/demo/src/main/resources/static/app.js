window.onload = () => {
    if (!localStorage.getItem('bienvenidaMostrada')) {
        document.getElementById('modal-bienvenida').classList.remove('hidden');
    }
};

const API_PRODUCTOS = 'http://localhost:8080/api/productos';
let productosLocales = []; 
let carritoArray = []; 

// ==========================================
// 1. INICIALIZACIÓN
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    cargarCatalogo();

    const inputBusqueda = document.getElementById('input-busqueda');
    if (inputBusqueda) {
        inputBusqueda.addEventListener('input', (e) => {
            const textoBuscado = e.target.value.toLowerCase();
            const filtrados = productosLocales.filter(p => 
                p.nombre.toLowerCase().includes(textoBuscado) || 
                p.tipoProducto.toLowerCase().includes(textoBuscado)
            );
            renderizarProductos(filtrados);
        });
    }

    const formCheckout = document.getElementById('form-checkout');
    if (formCheckout) {
        formCheckout.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const inputDir = document.getElementById('envio-dir');
            const inputNombre = document.getElementById('envio-nombre');
            
            if (!inputDir || !inputNombre) {
                console.error("Faltan IDs en el HTML: envio-dir o envio-nombre");
                return;
            }

            const idPedido = "CB-" + Math.floor(Math.random() * 9000 + 1000);
            const direccion = inputDir.value;
            const pagoMetodo = document.getElementById('pago-metodo')?.value || "Efecty";

            document.getElementById('track-id').innerText = `ID: #${idPedido}`;
            document.getElementById('track-pago').innerText = `Confirmado vía ${pagoMetodo}`;
            document.getElementById('track-envio').innerText = "En preparación (Bodega Turbaco)";

            cerrarCheckout();
            document.getElementById('modal-seguimiento').classList.remove('hidden');

            for (const item of carritoArray) {
                try {
                    await fetch(`${API_PRODUCTOS}/comprar/${item.producto.id}?cantidad=${item.cantidad}`, { 
                        method: 'POST' 
                    });
                } catch (error) { 
                    console.error("Error en stock:", item.producto.id); 
                }
            }

            mostrarNotificacion(`Pedido ${idPedido} para ${inputNombre.value} exitoso`, "exito");
            
            carritoArray = [];
            dibujarCarrito();
            formCheckout.reset();
            cargarCatalogo(); 
        });
    }

    const formLogin = document.getElementById('form-login');
    if (formLogin) {
        formLogin.addEventListener('submit', (e) => { e.preventDefault(); cerrarLogin(); });
    }
    const formReg = document.getElementById('form-registro');
    if (formReg) {
        formReg.addEventListener('submit', (e) => {
            e.preventDefault();
            mostrarNotificacion("¡Cuenta creada exitosamente!", "exito");
            toggleAuth('login');
        });
    }
});

// ==========================================
// 2. MODALES Y TOASTS (INTERFAZ)
// ==========================================
function cerrarBienvenida() {
    document.getElementById('modal-bienvenida').classList.add('hidden');
    localStorage.setItem('bienvenidaMostrada', 'true'); 
}

function abrirLogin() { document.getElementById('modal-login').classList.remove('hidden'); }
function cerrarLogin() { document.getElementById('modal-login').classList.add('hidden'); }
function abrirCarrito() { document.getElementById('modal-carrito').classList.remove('hidden'); }
function cerrarCarrito() { document.getElementById('modal-carrito').classList.add('hidden'); }
function cerrarCheckout() { document.getElementById('modal-checkout').classList.add('hidden'); }

function cerrarSeguimiento() { 
    document.getElementById('modal-seguimiento').classList.add('hidden'); 
}

function toggleAuth(modo) {
    const fLogin = document.getElementById('form-login');
    const fReg = document.getElementById('form-registro');
    const tLogin = document.getElementById('tab-login');
    const tReg = document.getElementById('tab-registro');

    if (!fLogin || !fReg || !tLogin || !tReg) return;

    if (modo === 'login') {
        fLogin.classList.remove('hidden');
        fReg.classList.add('hidden');
        tLogin.classList.add('text-pink-500', 'border-b-2', 'border-pink-500');
        tLogin.classList.remove('text-gray-400');
        tReg.classList.remove('text-pink-500', 'border-b-2', 'border-pink-500');
        tReg.classList.add('text-gray-400');
    } else {
        fReg.classList.remove('hidden');
        fLogin.classList.add('hidden');
        tReg.classList.add('text-pink-500', 'border-b-2', 'border-pink-500');
        tReg.classList.remove('text-gray-400');
        tLogin.classList.remove('text-pink-500', 'border-b-2', 'border-pink-500');
        tLogin.classList.add('text-gray-400');
    }
}

function mostrarNotificacion(mensaje, tipo = 'exito') {
    const contenedor = document.getElementById('toast-container');
    const toast = document.createElement('div');
    let color = tipo === 'exito' ? 'bg-white text-gray-800 border-pink-200' : 'bg-gray-900 text-white border-gray-800';
    let icono = tipo === 'exito' ? '<i class="fa-solid fa-circle-check text-pink-500"></i>' : '<i class="fa-solid fa-circle-exclamation text-red-500"></i>';

    toast.className = `toast-enter flex items-center gap-3 ${color} border-2 px-5 py-4 rounded-2xl shadow-xl min-w-[250px]`;
    toast.innerHTML = `${icono} <span class="font-bold text-sm">${mensaje}</span>`;
    contenedor.appendChild(toast);

    setTimeout(() => {
        toast.classList.replace('toast-enter', 'toast-exit');
        setTimeout(() => toast.remove(), 400); 
    }, 3500);
}

// ==========================================
// 3. CATÁLOGO Y FONDOS DINÁMICOS
// ==========================================
async function cargarCatalogo() {
    try {
        const respuesta = await fetch(API_PRODUCTOS);
        const datos = await respuesta.json();
        if (datos && datos.length > 0) {
            productosLocales = datos;
        } else {
            cargarPlanC();
        }
    } catch (error) {
        cargarPlanC();
    }
    renderizarProductos(productosLocales);
}

function cargarPlanC() {
    productosLocales = [
        { id: 1, tipoProducto: "MANGA", nombre: "Dragon Ball Z Vol. 1", precio: 45000, stock: 10, imagenUrl: "https://m.media-amazon.com/images/I/81c-89S2XGL.jpg" },
        { id: 2, tipoProducto: "MANHWA", nombre: "La noche que llega a la ribera", precio: 60000, stock: 5, imagenUrl: "https://m.media-amazon.com/images/I/71R2vH5Y3dL.jpg" },
        { id: 3, tipoProducto: "MANGA", nombre: "Attack on Titan Vol. 34", precio: 78000, stock: 15, imagenUrl: "https://m.media-amazon.com/images/I/815uVxpIP3L.jpg" },
        { id: 4, tipoProducto: "MANHWA", nombre: "Solo Leveling Vol. 1", precio: 29000, stock: 20, imagenUrl: "https://m.media-amazon.com/images/I/718yG0Z7j1L.jpg" },
        { id: 5, tipoProducto: "FIGURA", nombre: "One Piece Roronoa Zoro", precio: 74000, stock: 3, imagenUrl: "https://m.media-amazon.com/images/I/71J1b80QYcL.jpg" },
        { id: 6, tipoProducto: "ALBUM", nombre: "BLACKPINK [BORN PINK]", precio: 38000, stock: 8, imagenUrl: "https://m.media-amazon.com/images/I/51wV33b6mBL.jpg" }
    ];
}

function renderizarProductos(lista) {
    const contenedor = document.getElementById('contenedor-productos');
    if (!contenedor) return;
    contenedor.innerHTML = ''; 

    lista.forEach(p => {
        const imgSegura = p.imagenUrl ? p.imagenUrl : 'https://via.placeholder.com/300x400?text=Asian+Spot';
        let badge = p.tipoProducto === 'MANGA' ? 'bg-pink-500' : 'bg-cyan-500';

        contenedor.innerHTML += `
            <div class="bg-white rounded-2xl p-4 shadow-sm hover:shadow-xl transition-all border-2 border-pink-50 flex flex-col justify-between h-full group">
                <div class="relative overflow-hidden rounded-xl mb-4 h-64 bg-slate-100">
                    <span class="absolute top-2 left-2 ${badge} text-white text-[10px] font-bold px-2 py-1 rounded-full z-10 uppercase">${p.tipoProducto}</span>
                    <img src="${imgSegura}" alt="${p.nombre}" class="object-cover w-full h-full group-hover:scale-110 transition duration-500" onerror="this.src='https://via.placeholder.com/300x400?text=Asian+Spot'">
                </div>
                <div>
                    <h4 class="font-bold text-gray-800 text-sm leading-tight mb-2 line-clamp-2">${p.nombre}</h4>
                    <div class="flex justify-between items-end mt-2">
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase font-bold">Stock: ${p.stock}</p>
                            <span class="text-xl font-black text-gray-900">$${p.precio.toLocaleString()}</span>
                        </div>
                        <button onclick="procesarCompra(${p.id})" class="bg-gray-900 text-white w-10 h-10 rounded-xl hover:bg-pink-500 transition-colors flex items-center justify-center">
                            <i class="fa-solid fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
}

function filtrar(categoria) {
    const config = {
        'MANGA': { c: 'bg-orange-50', t: '🌸 Colección Manga', s: 'Las mejores historias en blanco y negro' },
        'MANHWA': { c: 'bg-cyan-50', t: '💥 Webtoons y Manhwa', s: 'Acción, magia y romance a todo color' },
        'FIGURA': { c: 'bg-green-50', t: '✨ Figuras de Colección', s: 'Tus personajes favoritos en tu estantería' },
        'ALBUM': { c: 'bg-purple-50', t: '🎤 Zona K-Pop', s: 'Álbumes y mercancía oficial' },
        'TODOS': { c: 'bg-slate-50', t: 'Catálogo General', s: 'Descubre todas nuestras novedades' }
    };

    const actual = config[categoria] || config['TODOS'];
    document.body.className = `font-sans transition-colors duration-700 ${actual.c}`;
    
    document.getElementById('titulo-seccion').innerText = actual.t;
    document.getElementById('subtitulo-seccion').innerText = actual.s;

    if (categoria === 'TODOS') {
        renderizarProductos(productosLocales);
    } else {
        renderizarProductos(productosLocales.filter(p => p.tipoProducto === categoria));
    }
}

// ==========================================
// 4. EL CARRITO INTELIGENTE
// ==========================================
async function procesarCompra(id) {
    const productoBase = productosLocales.find(p => p.id === id);
    if (!productoBase) return;

    const itemEnCarrito = carritoArray.find(item => item.producto.id === id);

    if (itemEnCarrito) {
        cambiarCantidad(id, 1);
    } else {
        if (productoBase.stock > 0) {
            carritoArray.push({ producto: productoBase, cantidad: 1 });
            mostrarNotificacion(`Añadido: ${productoBase.nombre}`, 'exito');
            dibujarCarrito();
        } else {
            mostrarNotificacion(`Producto agotado.`, 'error');
        }
    }
}

function cambiarCantidad(idProducto, cambio) {
    const item = carritoArray.find(i => i.producto.id === idProducto);
    if (!item) return;

    const nuevaCantidad = item.cantidad + cambio;
    if (nuevaCantidad < 1) return; 

    if (nuevaCantidad > item.producto.stock) {
        mostrarNotificacion(`Solo hay ${item.producto.stock} en stock.`, 'error');
        return;
    }

    item.cantidad = nuevaCantidad;
    dibujarCarrito();
}

function eliminarDelCarrito(idProducto) {
    carritoArray = carritoArray.filter(item => item.producto.id !== idProducto);
    dibujarCarrito();
}

function dibujarCarrito() {
    const contenedor = document.getElementById('items-carrito');
    const labelTotal = document.getElementById('total-carrito');
    const badgeCart = document.getElementById('cart-count');
    
    let totalDinero = 0;
    let totalItems = 0;

    carritoArray.forEach(item => {
        totalDinero += (item.producto.precio * item.cantidad);
        totalItems += item.cantidad;
    });

    if(badgeCart) badgeCart.innerText = totalItems;

    if (carritoArray.length === 0) {
        contenedor.innerHTML = '<p class="text-gray-400 text-center mt-10 text-sm font-bold">Tu carrito está vacío 🌸</p>';
        labelTotal.innerText = "$0";
        return;
    }

    contenedor.innerHTML = '';
    carritoArray.forEach(item => {
        contenedor.innerHTML += `
            <div class="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 group">
                <img src="${item.producto.imagenUrl}" class="w-14 h-20 object-cover rounded-md" onerror="this.src='https://via.placeholder.com/300x400?text=Asian+Spot'">
                <div class="flex-1">
                    <h5 class="text-[11px] font-bold text-gray-800 uppercase line-clamp-1">${item.producto.nombre}</h5>
                    <span class="text-sm font-black text-pink-500">$${(item.producto.precio * item.cantidad).toLocaleString()}</span>
                    <div class="flex items-center gap-3 mt-2">
                        <div class="flex items-center bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                            <button onclick="cambiarCantidad(${item.producto.id}, -1)" class="px-2 bg-gray-50 hover:bg-pink-500 hover:text-white font-bold text-xs">-</button>
                            <span class="px-2 text-xs font-bold w-6 text-center">${item.cantidad}</span>
                            <button onclick="cambiarCantidad(${item.producto.id}, 1)" class="px-2 bg-gray-50 hover:bg-pink-500 hover:text-white font-bold text-xs">+</button>
                        </div>
                    </div>
                </div>
                <button onclick="eliminarDelCarrito(${item.producto.id})" class="text-gray-300 hover:text-red-500 bg-white rounded-full w-6 h-6 flex items-center justify-center shadow-sm"><i class="fa-solid fa-trash text-xs"></i></button>
            </div>
        `;
    });
    
    labelTotal.innerText = "$" + totalDinero.toLocaleString();
}

function finalizarCompra() {
    if(carritoArray.length === 0) {
        mostrarNotificacion("Tu carrito está vacío.", "error");
        return;
    }
    cerrarCarrito();
    document.getElementById('modal-checkout').classList.remove('hidden');
    document.getElementById('checkout-total').innerText = document.getElementById('total-carrito').innerText;
}