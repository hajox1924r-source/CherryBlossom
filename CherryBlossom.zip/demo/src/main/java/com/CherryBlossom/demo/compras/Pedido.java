package com.CherryBlossom.demo.compras;

import com.CherryBlossom.demo.enums.EstadoPedido;
import java.util.Date;
import java.util.List;

public class Pedido {

    private int id;
    private Date fecha;
    private EstadoPedido estado;
    private double total;
    private List<ItemPedido> items;
    private Pago pago;
    private Envio envio;

    public Pedido() {
    }

    public Pedido(int id, Date fecha, EstadoPedido estado, double total, List<ItemPedido> items) {
        this.id = id;
        this.fecha = fecha;
        this.estado = estado;
        this.total = total;
        this.items = items;
    }

    public void confirmarPedido() {
        this.estado = EstadoPedido.PENDIENTE;
        System.out.println("Pedido " + id + " confirmado.");
    }

    public void cancelarPedido() {
        this.estado = EstadoPedido.CANCELADO;
        System.out.println("Pedido " + id + " cancelado.");
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public EstadoPedido getEstado() {
        return estado;
    }

    public void setEstado(EstadoPedido estado) {
        this.estado = estado;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public List<ItemPedido> getItems() {
        return items;
    }

    public void setItems(List<ItemPedido> items) {
        this.items = items;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public Envio getEnvio() {
        return envio;
    }

    public void setEnvio(Envio envio) {
        this.envio = envio;
    }
}
