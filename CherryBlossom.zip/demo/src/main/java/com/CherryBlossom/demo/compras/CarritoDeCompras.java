package com.CherryBlossom.demo.compras;

import java.util.ArrayList;
import java.util.List;

public class CarritoDeCompras {

    private List<ItemCarrito> items;
    private double total;

    public CarritoDeCompras() {
        this.items = new ArrayList<>();
        this.total = 0.0;
    }

    public void agregarProducto(ItemCarrito item) {
        this.items.add(item);
        calcularTotal();
    }

    public void eliminarProducto(ItemCarrito item) {
        this.items.remove(item);
        calcularTotal();
    }

    public double calcularTotal() {
        this.total = 0;
        for (ItemCarrito item : items) {
            this.total += item.getSubtotal();
        }
        return this.total;
    }

    public List<ItemCarrito> getItems() {
        return items;
    }

    public void setItems(List<ItemCarrito> items) {
        this.items = items;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
}
