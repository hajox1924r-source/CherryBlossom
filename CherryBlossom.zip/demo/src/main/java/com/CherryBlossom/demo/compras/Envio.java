package com.CherryBlossom.demo.compras;

import com.CherryBlossom.demo.enums.EstadoEnvio;
import java.util.Date;

public class Envio {

    private String direccion;
    private EstadoEnvio estado;
    private Date fechaEntregaEstimada;

    public Envio() {
    }

    public Envio(String direccion, EstadoEnvio estado, Date fechaEntregaEstimada) {
        this.direccion = direccion;
        this.estado = estado;
        this.fechaEntregaEstimada = fechaEntregaEstimada;
    }

    public void actualizarEstado(EstadoEnvio nuevoEstado) {
        this.estado = nuevoEstado;
        System.out.println("Estado del envío actualizado a: " + nuevoEstado);
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public EstadoEnvio getEstado() {
        return estado;
    }

    public void setEstado(EstadoEnvio estado) {
        this.estado = estado;
    }

    public Date getFechaEntregaEstimada() {
        return fechaEntregaEstimada;
    }

    public void setFechaEntregaEstimada(Date fechaEntregaEstimada) {
        this.fechaEntregaEstimada = fechaEntregaEstimada;
    }
}
