package com.CherryBlossom.demo.productos;

public class Manga extends ProductoEditorial {

    private int tomo;
    private String isbn;

    public Manga() {
        super();
    }

    public Manga(int id, String nombre, double precio, int stock, String descripcion, double peso, String autor, String editorial, int numeroPaginas, int tomo, String isbn) {
        super(id, nombre, precio, stock, descripcion, peso, autor, editorial, numeroPaginas);
        this.tomo = tomo;
        this.isbn = isbn;
    }

    public int getTomo() {
        return tomo;
    }

    public void setTomo(int tomo) {
        this.tomo = tomo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }
}
