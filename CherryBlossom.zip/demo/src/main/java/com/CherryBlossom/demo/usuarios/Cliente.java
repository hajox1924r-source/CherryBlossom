package com.CherryBlossom.demo.usuarios;

public class Cliente extends Usuario {
    private String direccion;
    private String telefono;
    
    public Cliente() {
        super();
    }
    
    public Cliente(int id, String nombre, String correo, String contrasena, String direccion, String telefono) {
       super(id, nombre, correo, contrasena);
        this.direccion = direccion;
        this.telefono = telefono;
    }
    
    // Getters y Setters 
    
    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
