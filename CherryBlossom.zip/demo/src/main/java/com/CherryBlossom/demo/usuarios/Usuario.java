package com.CherryBlossom.demo.usuarios;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "tipoUsuario")
@JsonSubTypes({
    @JsonSubTypes.Type(value = Cliente.class, name = "CLIENTE"),
    @JsonSubTypes.Type(value = Administrador.class, name = "ADMINISTRADOR")
})

public abstract class Usuario {

    private int id;
    private String nombre;
    private String correo;
    private String contrasena;
    private String rol;

public Usuario() {
}
public Usuario(int id, String nombre, String correo, String contrasena) {
    this.id = id;
    this.nombre = nombre;
    this.correo = correo;
    this.contrasena = contrasena;
}

    public boolean inicarSesion(String correoIngresado, String contraseñaIngresada) {
        return this.correo.equals(correoIngresado) && this.contrasena.equals(contraseñaIngresada);
    }

    public void cerrarSesion() {
        System.out.println("Cerrando sesión para el usuario:    "   +   this.nombre);
    }
    
    // Getters y Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCorreo() {
        return correo;
    }
    
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public String getContrasena() {
        return contrasena;
    }
    
    public void setContraseña(String cotrasena) {
        this.contrasena = contrasena;
    }

    public void setContrasena(String admin123) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    public void setRol(String admin) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}
