package com.CherryBlossom.demo.pagos;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "tipoMetodo")
@JsonSubTypes({
    @JsonSubTypes.Type(value = PagoTarjeta.class, name = "TARJETA"),
    @JsonSubTypes.Type(value = PagoPayPal.class, name = "PAYPAL"),
    @JsonSubTypes.Type(value = PagoNequi.class, name = "NEQUI")
})

public interface MetodoPago {
    boolean procesarPago();
}
