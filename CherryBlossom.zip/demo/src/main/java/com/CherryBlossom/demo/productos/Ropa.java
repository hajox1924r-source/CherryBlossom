package com.CherryBlossom.demo.productos;

public class Ropa extends Merchandising {

    private String talla;

    public Ropa() {
        super();
    }

    public Ropa(int id, String nombre, double precio, int stock, String descripcion, double peso, String material, String talla) {
        super(id, nombre, precio, stock, descripcion, peso, material);
        this.talla = talla;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }
}
