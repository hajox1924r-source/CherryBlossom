package com.CherryBlossom.demo.pagos;

public class PagoNequi implements MetodoPago {

    private String numeroCelular;

    public PagoNequi() {
    }

    public PagoNequi(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

@Override
public boolean procesarPago() {
    System.out.println("Enviando notificacion push de cobro al celular Nequi: " + numeroCelular);
    return true;
}

    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }
}
