package com.CherryBlossom.demo.productos;

public class AlbumMusical extends ProductoFisico {

    private String artista;
    private int numeroCanciones;

    public AlbumMusical() {
        super();
    }

    public AlbumMusical(int id, String nombre, double precio, int stock, String descripcion, double peso, String artista, int numeroCanciones) {
        super(id, nombre, precio, stock, descripcion, peso);
        this.artista = artista;
        this.numeroCanciones = numeroCanciones;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getNumeroCanciones() {
        return numeroCanciones;
    }

    public void setNumeroCanciones(int numeroCanciones) {
        this.numeroCanciones = numeroCanciones;
    }
}
