package com.CherryBlossom.demo.productos;

public class NovelaLigera extends ProductoEditorial {
    private int volumen;
    private String ilustrador;

    public NovelaLigera() { super(); }

    public NovelaLigera(int id, String nombre, double precio, int stock, String descripcion, double peso, String autor, String editorial, int numeroPaginas, int volumen, String ilustrador) {
        super(id, nombre, precio, stock, descripcion, peso, autor, editorial, numeroPaginas);
        this.volumen = volumen;
        this.ilustrador = ilustrador;
    }

    public int getVolumen() { return volumen; }
    public void setVolumen(int volumen) { this.volumen = volumen; }
    public String getIlustrador() { return ilustrador; }
    public void setIlustrador(String ilustrador) { this.ilustrador = ilustrador; }
}