package com.CherryBlossom.demo.usuarios;
import java.util.Date;

public class Pedido {
    private String idPedido;
    private String fecha;
    private double total;
    private String estadoPago;
    private String estadoEnvio;
    private String direccionEnvio;

    public Pedido(String idPedido, double total, String direccionEnvio) {
        this.idPedido = idPedido;
        this.fecha = new Date().toString();
        this.total = total;
        this.direccionEnvio = direccionEnvio;
        this.estadoPago = "Confirmado (PSE/Tarjeta)";
        this.estadoEnvio = "En preparación (Bodega)";
    }

    // Getters y Setters
    public String getIdPedido() {
        return idPedido;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public String getEstadoEnvio() {
        return estadoEnvio;
    }

    public double getTotal() {
        return total;
    }
}
