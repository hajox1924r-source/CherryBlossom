package com.CherryBlossom.demo.productos;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "tipoProducto")
@JsonSubTypes({
    @JsonSubTypes.Type(value = Manga.class, name = "MANGA"),
    @JsonSubTypes.Type(value = Manhwa.class, name = "MANHWA"),
    @JsonSubTypes.Type(value = NovelaLigera.class, name = "NOVELA_LIGERA"),
    @JsonSubTypes.Type(value = Ropa.class, name = "ROPA"),
    @JsonSubTypes.Type(value = Accesorios.class, name = "ACCESORIO"),
    @JsonSubTypes.Type(value = Posters.class, name = "POSTER"),
    @JsonSubTypes.Type(value = FiguraColeccionable.class, name = "FIGURA"),
    @JsonSubTypes.Type(value = AlbumMusical.class, name = "ALBUM"),
    @JsonSubTypes.Type(value = ProductoDigital.class, name = "DIGITAL")
})

public class Producto {

    private int id;
    private String nombre;
    private double precio;
    private int stock;
    private String descripcion;
    private String tipoProducto;
    private String imagenUrl;

    public Producto() {
    }

    public Producto(int id, String nombre, double precio, int stock, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }
}
