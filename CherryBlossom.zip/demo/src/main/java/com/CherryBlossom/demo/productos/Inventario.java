package com.CherryBlossom.demo.productos;

public class Inventario {

    private int cantidadDisponible;
    private int cantidadReservada;

    public Inventario() {
    }

    public Inventario(int cantidadDisponible, int cantidadReservada) {
        this.cantidadDisponible = cantidadDisponible;
        this.cantidadReservada = cantidadReservada;
    }

    public void actualizarStock(int cantidadModificada) {
        this.cantidadDisponible += cantidadModificada;
        System.out.println("Stock actualizado. Disponible: " + this.cantidadDisponible);
    }

    public int getCantidadDisponible() {
        return cantidadDisponible;
    }

    public void setCantidadDisponible(int cantidadDisponible) {
        this.cantidadDisponible = cantidadDisponible;
    }

    public int getCantidadReservada() {
        return cantidadReservada;
    }

    public void setCantidadReservada(int cantidadReservada) {
        this.cantidadReservada = cantidadReservada;
    }
}
