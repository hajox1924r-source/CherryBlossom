package com.CherryBlossom.demo.pagos;

public class PagoPayPal implements MetodoPago {
    private String correoPayPal;
    
    public PagoPayPal(){
    }
    
    public PagoPayPal(String correoPayPal) {
        this.correoPayPal = correoPayPal;
    }
    
    @Override 
    public boolean procesarPago() {
        System.out.println("Conectando con la API de PayPal para el correo:  "   +  correoPayPal);
        return true;
    }
    
    public String getCorreoPayPal() {
        return correoPayPal;
    }
    
    public void setCorreoPayPal(String correoPayPal) {
        this.correoPayPal = correoPayPal;
    }
}
