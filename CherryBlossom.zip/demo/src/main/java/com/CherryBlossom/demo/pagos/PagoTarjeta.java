package com.CherryBlossom.demo.pagos;

public class PagoTarjeta implements MetodoPago {
    private String numeroTarjeta;
    
    public PagoTarjeta(){
    }
    
    public PagoTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }
    
    @Override 
    public boolean procesarPago() {
        System.out.println("Procesando pago con tarjeta terminada en    "   +   numeroTarjeta.substring(numeroTarjeta.length() - 4));
        return true;
    }
    
    public String numeroTarjeta() {
        return numeroTarjeta;
    }
    
    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }
}
