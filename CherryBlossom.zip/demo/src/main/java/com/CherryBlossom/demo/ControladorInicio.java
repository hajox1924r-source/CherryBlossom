package com.CherryBlossom.demo;

import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // <-- ¡Esta es vital para que no salga el error 404!
public class ControladorInicio {

    @GetMapping("/saludo") // <-- Asegúrate de que tenga la barra inclinada (/)
    public String decirHola() {
        return "¡Por fin funciono esta mierda.";
    }
    @GetMapping("/api/configuracion")
public Map<String, String> obtenerConfig() {
    Map<String, String> datos = new HashMap<>();
    datos.put("usuario", "Estudiante de Ingeniería");
    datos.put("universidad", "Fundación Universitaria");
    datos.put("estado", "Conectado");
    return datos; // Spring lo convierte a JSON automáticamente
}
}