package com.CherryBlossom.demo.usuarios;

public class Administrador  extends Usuario{
    
    public Administrador() {
        super();
    }
    
    public Administrador(int id, String nombre, String correo, String contrasena) {
        super(id, nombre, correo, contrasena);
    }

    public void gestionarProductos() {
        System.out.println("Abriendo panel de gestión de productos...");
    }

    public void gestionarPedidos() {
        System.out.println("Abriendo panel de gestión de pedidos...");
    }
}
