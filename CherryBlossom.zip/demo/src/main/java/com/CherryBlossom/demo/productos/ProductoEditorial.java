package com.CherryBlossom.demo.productos;

public abstract class ProductoEditorial extends ProductoFisico {

    private String autor;
    private String editorial;
    private int numeroPaginas;

    public ProductoEditorial() {
        super();
    }

public ProductoEditorial(int id, String nombre, double precio, int stock, String descripcion, double peso, String autor, String editorial, int numeroPaginas) {
        super(id, nombre, precio, stock, descripcion, peso);
        this.autor = autor;
        this.editorial = editorial;
        this.numeroPaginas = numeroPaginas;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }
}
