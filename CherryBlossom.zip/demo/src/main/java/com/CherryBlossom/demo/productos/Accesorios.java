package com.CherryBlossom.demo.productos;

public class Accesorios extends Merchandising {

    private String tipo;

    public Accesorios() {
        super();
    }

    public Accesorios(int id, String nombre, double precio, int stock, String descripcion, double peso, String material, String tipo) {
        super(id, nombre, precio, stock, descripcion, peso, material);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
