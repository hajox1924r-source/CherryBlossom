package com.CherryBlossom.demo.repository;

import com.CherryBlossom.demo.productos.Producto;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductoFileRepository {

    private static final List<Producto> lista = new ArrayList<>();

    static {
        // Llenando el catálogo con tus nuevas URLs de ImgBB
        lista.add(crearP(1, "MANGA", "One Piece Vol. 100", 55000, 12, "https://i.ibb.co/ZkVTdv9/1.webp"));
        lista.add(crearP(2, "MANHWA", "Painter of the Night (BL) Vol. 1", 85000, 8, "https://i.ibb.co/prRNqMh6/2.jpg"));
        lista.add(crearP(3, "FIGURA", "One Piece Roronoa Zoro", 74000, 3, "https://i.ibb.co/Myb59Zdk/3.jpg"));
        lista.add(crearP(4, "ALBUM", "BTS - Proof (Standard Edition)", 280000, 5, "https://i.ibb.co/4ZJWMG4J/4.jpg"));
        lista.add(crearP(5, "MANHWA", "BJ Alex (BL) Vol. 1", 90000, 6, "https://i.ibb.co/qLc4rdfM/5.webp"));
        lista.add(crearP(6, "ALBUM", "Blackpink - Born Pink", 95000, 15, "https://i.ibb.co/bMVTm6x7/6.jpg"));
        lista.add(crearP(7, "FIGURA", "Jujutsu Kaisen - Gojo Satoru", 320000, 3, "https://i.ibb.co/21CzmVZQ/7.jpg"));
        lista.add(crearP(8, "ALBUM", "BabyMetal - Logo T-Shirt", 110000, 10, "https://i.ibb.co/Z56bGLc/8.jpg"));
        lista.add(crearP(9, "MANGA", "Spy x Family Vol. 1", 42000, 20, "https://i.ibb.co/1GF2c5PJ/9.webp"));
        lista.add(crearP(10, "FIGURA", "Demon Slayer - Tanjiro Kamado", 150000, 7, "https://i.ibb.co/KcgrhwfN/10.jpg"));
    }

    public List<Producto> obtenerTodos() {
        return lista;
    }

    public boolean reducirStock(int id, int cantidad) {
        for (Producto p : lista) {
            if (p.getId() == id) {
                if (p.getStock() >= cantidad) {
                    p.setStock(p.getStock() - cantidad);
                    return true;
                }
                break; 
            }
        }
        return false;
    }

    private static Producto crearP(int id, String tipo, String nombre, double precio, int stock, String url) {
        Producto p = new Producto();
        p.setId(id);
        p.setTipoProducto(tipo);
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setStock(stock);
        p.setImagenUrl(url);
        return p;
    }
}