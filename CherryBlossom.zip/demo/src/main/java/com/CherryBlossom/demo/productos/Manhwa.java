package com.CherryBlossom.demo.productos;

public class Manhwa extends ProductoEditorial {

    private int temporada;
    private String idioma;

    public Manhwa() {
        super();
    }

    public Manhwa(int id, String nombre, double precio, int stock, String descripcion, double peso, String autor, String editorial, int numeroPaginas, int temporada, String idioma) {
        super(id, nombre, precio, stock, descripcion, peso, autor, editorial, numeroPaginas);
        this.temporada = temporada;
        this.idioma = idioma;
    }

    public int getTemporada() {
        return temporada;
    }

    public void setTemporada(int temporada) {
        this.temporada = temporada;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }
}
