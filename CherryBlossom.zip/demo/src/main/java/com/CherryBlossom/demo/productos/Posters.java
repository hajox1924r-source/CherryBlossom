package com.CherryBlossom.demo.productos;

public class Posters extends Merchandising {

    private String dimensiones;

    public Posters() {
        super();
    }

    public Posters(int id, String nombre, double precio, int stock, String descripcion, double peso, String material, String dimensiones) {
        super(id, nombre, precio, stock, descripcion, peso, material);
        this.dimensiones = dimensiones;
    }

    public String getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(String dimensiones) {
        this.dimensiones = dimensiones;
    }
}
