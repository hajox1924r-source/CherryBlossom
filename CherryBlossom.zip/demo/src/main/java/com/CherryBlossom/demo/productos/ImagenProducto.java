package com.CherryBlossom.demo.productos;

public class ImagenProducto {

    private String url;
    private boolean principal;

    public ImagenProducto() {
    }

    public ImagenProducto(String url, boolean principal) {
        this.url = url;
        this.principal = principal;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isPrincipal() {
        return principal;
    }

    public void setPrincipal(boolean principal) {
        this.principal = principal;
    }
}
