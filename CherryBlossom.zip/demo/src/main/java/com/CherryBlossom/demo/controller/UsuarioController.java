package com.CherryBlossom.demo.controller;

import com.CherryBlossom.demo.usuarios.Usuario; // Ajustado a tu carpeta real
import com.CherryBlossom.demo.repository.UsuarioFileRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
public class UsuarioController {

    private final UsuarioFileRepository repository = new UsuarioFileRepository();

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {
        List<Usuario> usuarios = repository.obtenerTodos();
        
        for (Usuario u : usuarios) {
            if (u.getCorreo().equalsIgnoreCase(request.getCorreo()) && 
                u.getContrasena().equals(request.getContrasena())) {
                return "Bienvenido " + u.getNombre();
            }
        }
        return "Error: Credenciales incorrectas";
    }
}

// Asegúrate de que esta clase esté fuera de la anterior o en su propio archivo
class LoginRequest {
    private String correo;
    private String contrasena;

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
}