package com.CherryBlossom.demo.productos;

public class FiguraColeccionable extends ProductoFisico {

    private String escala;
    private String material;

    public FiguraColeccionable() {
        super();
    }

    public FiguraColeccionable(int id, String nombre, double precio, int stock, String descripcion, double peso, String escala, String material) {
        super(id, nombre, precio, stock, descripcion, peso);
        this.escala = escala;
        this.material = material;
    }

    public String getEscala() {
        return escala;
    }

    public void setEscala(String escala) {
        this.escala = escala;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
