package com.CherryBlossom.demo.productos;

public class Franquicia {

    private int id;
    private String nombre;
    private String autorOriginal;

    public Franquicia() {
    }

    public Franquicia(int id, String nombre, String autorOriginal) {
        this.id = id;
        this.nombre = nombre;
        this.autorOriginal = autorOriginal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutorOriginal() {
        return autorOriginal;
    }

    public void setAutorOriginal(String autorOriginal) {
        this.autorOriginal = autorOriginal;
    }
}
