package com.CherryBlossom.demo.controller;

import com.CherryBlossom.demo.productos.Producto;
import com.CherryBlossom.demo.service.ProductoService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/productos")
@CrossOrigin(origins = "*") 
public class ProductoController {

    private final ProductoService service;

    public ProductoController(ProductoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Producto> obtenerCatalogo() {
        return service.listarTodo();
    }

    @PostMapping("/comprar/{id}")
    public String comprar(@PathVariable int id, @RequestParam int cantidad) {
        try {
            service.venderProducto(id, cantidad);
            return "Compra realizada con éxito";
        } catch (Exception e) {
            return "Error en la compra: " + e.getMessage();
        }
    }
}
