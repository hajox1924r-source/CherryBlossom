package com.CherryBlossom.demo.productos;

public abstract class ProductoFisico extends Producto {
    private double peso;
    
    public ProductoFisico() {
        super();
    }
    
   public ProductoFisico(int id, String nombre, double precio, int stock, String descripcion, double peso) {
        super(id, nombre, precio, stock, descripcion); 
        this.peso = peso;
    }
    
    public double calculaCostoEnvio() {
        return 5000.0 + (peso * 2000.0);
    }
    
    public double getPeso() {
        return peso;
    }
    
    public void setPeso(double peso) {
        this.peso = peso;
    }
}
