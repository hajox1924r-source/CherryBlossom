package com.CherryBlossom.demo.productos;

public abstract class Merchandising extends ProductoFisico {

    private String material;

    public Merchandising() {
        super();
    }

    public Merchandising(int id, String nombre, double precio, int stock, String descripcion, double peso, String material) {
        super(id, nombre, precio, stock, descripcion, peso);
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
