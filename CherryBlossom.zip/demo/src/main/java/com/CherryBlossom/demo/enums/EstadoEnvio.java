package com.CherryBlossom.demo.enums;

public enum EstadoEnvio {
    PREPARADO,
    ENCAMINO,
    ENTREGADO,
    RETRASADO
}
