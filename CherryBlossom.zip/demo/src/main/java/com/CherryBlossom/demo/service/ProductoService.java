package com.CherryBlossom.demo.service;

import com.CherryBlossom.demo.productos.Producto;
import com.CherryBlossom.demo.repository.ProductoFileRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductoService {

    private final ProductoFileRepository repository;

    public ProductoService(ProductoFileRepository repository) {
        this.repository = repository;
    }

    public List<Producto> listarTodo() {
        return repository.obtenerTodos();
    }

    public void venderProducto(int id, int cantidad) throws Exception {
        boolean exito = repository.reducirStock(id, cantidad);

        if (!exito) {
            throw new Exception("No se pudo realizar la venta: Stock insuficiente o producto no encontrado.");
        }
    }
}