package com.CherryBlossom.demo.compras;

import com.CherryBlossom.demo.enums.EstadoPago;
import java.util.Date;
import com.CherryBlossom.demo.pagos.MetodoPago;

public class Pago {

    private int id;
    private Date fecha;
    private double monto;
    private EstadoPago estado;
    private MetodoPago metodoPago; // Asociación con la interfaz para el polimorfismo

    public Pago() {
    }

    public Pago(int id, Date fecha, double monto, EstadoPago estado, MetodoPago metodoPago) {
        this.id = id;
        this.fecha = fecha;
        this.monto = monto;
        this.estado = estado;
        this.metodoPago = metodoPago;
    }

    public boolean confirmarPago() {
        if (metodoPago != null && metodoPago.procesarPago()) {
            this.estado = EstadoPago.APROBADO;
            return true;
        }
        this.estado = EstadoPago.RECHAZADO;
        return false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public EstadoPago getEstado() {
        return estado;
    }

    public void setEstado(EstadoPago estado) {
        this.estado = estado;
    }

    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(MetodoPago metodoPago) {
        this.metodoPago = metodoPago;
    }
}
