package com.CherryBlossom.demo.productos;

public class ProductoDigital extends Producto {
    private String formato;
    private double tamanoMB;
    
    public ProductoDigital() {
        super();
    }
    
    public ProductoDigital(int id, String nombre, double precio, int stock, String descripcion, String formato, double tamanoMB){
        super(id, nombre, precio, stock, descripcion);
        this.formato = formato;
        this.tamanoMB = tamanoMB;
    }
    
    public void descargas() {
        System.out.println("Iniciando descarga del archivo  "   +   getNombre()  +   " en formato " + formato + "(" + tamanoMB + " MB)");
    }
    
    public String getFormato() {
        return formato;
    }
    
    public void setFormato(String formato) {
        this.formato = formato;
    }
    
    public double getTamanoMB() {
        return tamanoMB;
    }
    
    public void settamanoMB(double tamanoMB) {
        this. tamanoMB = tamanoMB;
    }
}
