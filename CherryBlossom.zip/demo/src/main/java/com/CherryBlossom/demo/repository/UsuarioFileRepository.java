package com.CherryBlossom.demo.repository;

import com.CherryBlossom.demo.usuarios.Usuario; 
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Repository;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsuarioFileRepository {
    private final String FILE_PATH = "data/usuarios.json";
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<Usuario> obtenerTodos() {
        try {
            File file = new File(FILE_PATH);
            if (!file.exists()) return new ArrayList<>();
            // El casteo correcto para Jackson
            return objectMapper.readValue(file, new TypeReference<List<Usuario>>(){});
        } catch (IOException e) {
            System.err.println("Error al leer usuarios: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}